# Overleaf submission package

Main file: main.tex

This package contains the authorship-polished manuscript source, bibliography,
supporting LaTeX tables, and all referenced figures. Upload the ZIP as a new
Overleaf project and compile main.tex.
